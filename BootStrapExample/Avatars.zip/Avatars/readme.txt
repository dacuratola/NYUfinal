
INTRODUCTION:
------------

Hello and thank you for purchasing our premium Avatar set.

This set includes vector files (AI and EPS) as well as PSD (vector shapes), SVG and PNG files (256x256 / 512x512).

We truly hope that you will enjoy these avatars and use them in all your amazing projects.


CHANGING COLORS:
---------------

Changing colors is really easy! Here is what you have to do:

1/ Open the Photoshop file.

2/ Find the avatar you want to customize and open its folder.

3/ Right click on the layer you want to customize and select "Blending Options..."

4/ In the menu, click on "Color Overlay" and change the color.



Please feel free to contact us via our website (Flat-Icons.com) or email (sales@flat-icons.com) if you need anything.


Let's make the web more beautiful... together ;)


Flat-Icons.com

